// ----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation. All rights reserved.
// ----------------------------------------------------------------------------

#ifndef MicrosoftAzureMobile_MicrosoftAzureMobile_h
#define MicrosoftAzureMobile_MicrosoftAzureMobile_h

#import "MSBlockDefinitions.h"
#import "MSClient.h"
#import "MSCoreDataStore.h"
#import "MSDateOffset.h"
#import "MSError.h"
#import "MSFilter.h"
#import "MSLoginController.h"
#import "MSManagedObjectObserver.h"
#import "MSPullSettings.h"
#import "MSConnectionConfiguration.h"
#import "MSPush.h"
#import "MSQuery.h"
#import "MSQueryResult.h"
#import "MSSyncContext.h"
#import "MSSyncContextReadResult.h"
#import "MSSyncTable.h"
#import "MSTable.h"
#import "MSTableOperation.h"
#import "MSTableOperationError.h"
#import "MSUser.h"
#import "MSInstallation.h"
#import "MSInstallationTemplate.h"

#define MicrosoftAzureMobileSdkMajorVersion 3
#define MicrosoftAzureMobileSdkMinorVersion 4
#define MicrosoftAzureMobileSdkBuildVersion 0

#endif
